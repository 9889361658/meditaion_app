-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2025 at 09:38 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meditation1`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`) VALUES
(1, 'a', 'a@gmail.com', 'stress', 'bdksgiusgduysgfdusfd', '2025-04-12 18:28:53'),
(2, 'a', 'a@gmail.com', 'stress', 'bdksgiusgduysgfdusfd', '2025-04-12 18:39:10'),
(3, 's', 'a@gmail.com', 'stress', 'gdfugduyfgdufgdufwdkygwu', '2025-04-12 19:40:46'),
(4, 's', 'a@gmail.com', 'stress', 'gdfugduyfgdufgdufwdkygwu', '2025-04-12 19:45:08'),
(5, 'aegr', 'feaw@gmail.com', 'faewggeag', 'eawg', '2025-04-15 19:38:12');

-- --------------------------------------------------------

--
-- Table structure for table `meditation_sessions`
--

CREATE TABLE `meditation_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `session_type` varchar(255) NOT NULL,
  `activity_type` varchar(20) NOT NULL DEFAULT 'meditation',
  `duration` int(11) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `meditation_sessions`
--

INSERT INTO `meditation_sessions` (`id`, `user_id`, `session_type`, `activity_type`, `duration`, `start_time`, `end_time`, `created_at`) VALUES
(1, 2, 'Beginner Meditation', 'meditation', 5, '2025-04-12 22:07:24', '2025-04-12 22:12:24', '2025-04-12 20:07:24'),
(2, 2, 'Stress Relief', 'meditation', 10, '2025-04-12 22:07:57', '2025-04-12 22:17:57', '2025-04-12 20:07:57'),
(3, 2, 'Deep Focus', 'meditation', 20, '2025-04-12 22:10:48', '2025-04-12 22:30:48', '2025-04-12 20:10:48'),
(4, 2, 'Stress Relief', 'meditation', 10, '2025-04-12 22:15:30', '2025-04-12 22:25:30', '2025-04-12 20:15:30'),
(5, 2, 'Deep Focus', 'meditation', 20, '2025-04-12 22:15:46', '2025-04-12 22:35:46', '2025-04-12 20:15:46'),
(6, 2, 'Beginner Meditation', 'meditation', 5, '2025-04-12 22:18:05', '2025-04-12 22:23:05', '2025-04-12 20:18:05'),
(7, 2, 'Beginner Meditation', 'meditation', 5, '2025-04-12 22:20:13', '2025-04-12 22:25:13', '2025-04-12 20:20:13'),
(8, 2, 'Morning Mindfulness', 'meditation', 5, '2025-04-12 22:20:20', '2025-04-12 22:25:20', '2025-04-12 20:20:20'),
(9, 2, 'Sleep Meditation', 'meditation', 10, '2025-04-12 22:20:33', '2025-04-12 22:30:33', '2025-04-12 20:20:33'),
(10, 2, 'Nature Connection', 'meditation', 20, '2025-04-12 22:20:41', '2025-04-12 22:40:41', '2025-04-12 20:20:41'),
(11, 2, 'Anxiety Relief', 'meditation', 15, '2025-04-12 22:22:42', '2025-04-12 22:37:42', '2025-04-12 20:22:42'),
(12, 3, 'Stress Relief', 'meditation', 10, '2025-04-12 22:37:38', '2025-04-12 22:47:38', '2025-04-12 20:37:38'),
(13, 3, 'Stress Relief', 'meditation', 10, '2025-04-12 22:42:00', '2025-04-12 22:52:00', '2025-04-12 20:42:00'),
(14, 3, 'Beginner Meditation', 'meditation', 5, '2025-04-12 22:44:16', '2025-04-12 22:49:16', '2025-04-12 20:44:16'),
(15, 3, 'Beginner Meditation', 'meditation', 5, '2025-04-12 22:45:28', '2025-04-12 22:50:28', '2025-04-12 20:45:28'),
(16, 3, 'Deep Focus', 'meditation', 20, '2025-04-12 22:48:00', '2025-04-12 23:08:00', '2025-04-12 20:48:00'),
(17, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 08:19:08', '2025-04-13 08:29:08', '2025-04-13 06:19:08'),
(18, 4, 'Beginner Meditation', 'meditation', 5, '2025-04-13 08:22:37', '2025-04-13 08:27:37', '2025-04-13 06:22:37'),
(19, 4, 'Beginner Meditation', 'meditation', 5, '2025-04-13 08:26:11', '2025-04-13 08:31:11', '2025-04-13 06:26:11'),
(20, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 08:31:49', '2025-04-13 08:41:49', '2025-04-13 06:31:49'),
(21, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 08:37:40', '2025-04-13 08:47:40', '2025-04-13 06:37:40'),
(22, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 08:39:14', '2025-04-13 08:49:14', '2025-04-13 06:39:14'),
(23, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 09:03:32', '2025-04-13 09:13:32', '2025-04-13 07:03:32'),
(24, 4, 'Beginner Meditation', 'meditation', 5, '2025-04-13 09:08:49', '2025-04-13 09:13:49', '2025-04-13 07:08:49'),
(25, 4, 'Beginner Meditation', 'meditation', 5, '2025-04-13 09:18:46', '2025-04-13 09:23:46', '2025-04-13 07:18:46'),
(26, 4, 'Stress Relief', 'meditation', 10, '2025-04-13 09:27:01', '2025-04-13 09:37:01', '2025-04-13 07:27:01'),
(27, 5, 'Stress Relief', 'meditation', 10, '2025-04-13 14:49:07', '2025-04-13 14:59:07', '2025-04-13 12:49:07'),
(28, 5, 'Stress Relief', 'meditation', 10, '2025-04-13 14:49:53', '2025-04-13 14:59:53', '2025-04-13 12:49:53'),
(29, 7, 'Beginner Meditation', 'meditation', 5, '2025-04-15 21:36:28', '2025-04-15 21:41:28', '2025-04-15 19:36:28'),
(30, 7, 'Beginner Meditation', 'meditation', 5, '2025-04-15 21:36:34', '2025-04-15 21:41:34', '2025-04-15 19:36:34'),
(31, 7, 'Beginner Meditation', 'meditation', 5, '2025-04-15 21:36:51', '2025-04-15 21:41:51', '2025-04-15 19:36:51'),
(32, 7, 'Beginner Stretch', 'exercise', 5, '2025-04-15 21:37:40', '2025-04-15 21:42:40', '2025-04-15 19:37:40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'a', 'a@gmail.com', '$2y$10$fwEVhfrAoGzQHQ.eJGNf2.49KmMfpfwKMTfwKIAv8f/G4cGVs5sKi', '2025-04-12 18:52:14'),
(2, '112', 'asd@gmail.com', '$2y$10$vA61XfddSyvKDtS3kBY6MewbJMj13y/WjSo6GwOMayflkC23Pt9xO', '2025-04-12 19:33:31'),
(3, 'z', 'z@gmail.com', '$2y$10$xSur5N0/3GT/tPKAm6xNTugoNrIhwmxiPT5CT7duk0ntvOaxiR9am', '2025-04-12 20:36:43'),
(4, '2', '1@gmail.com', '$2y$10$jtzA0PmqpsLBdMAvj1eaIu3to2QRQ8QxBHELWGNelnLKZjZrq/qcm', '2025-04-13 06:17:32'),
(5, 'sh', 'sh@gmail.com', '$2y$10$CfiEJnCB4cKqY0EVSNJ9keLOqWoalS5OSFMg55rV9litF.KpG3G7S', '2025-04-13 12:48:06'),
(6, 's', 's@gmail.com', '$2y$10$hhrfCID2GNMfk2Ukh1lo8.HP0rv7FR.9oegFqKYpOKiP/Wvrn4aoO', '2025-04-14 09:01:34'),
(7, 'r', 'r@gmail.com', '$2y$10$dkzY89jtJ0tVQgQUuRfb8O7ajiJ2M12bdkc2OHNXvjIn2Grbp2Ery', '2025-04-15 19:32:43');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meditation_sessions`
--
ALTER TABLE `meditation_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `unique_email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `meditation_sessions`
--
ALTER TABLE `meditation_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
